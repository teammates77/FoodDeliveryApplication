package com.restaurentservice1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantService1Application {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantService1Application.class, args);
	}

}
